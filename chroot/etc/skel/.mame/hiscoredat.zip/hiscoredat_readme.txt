
This is the hiscore.dat for the m.a.m.e. emulator.
This file used in conjunction with a specially compiled mame that supports the hiscore.dat file
will save many more hiscores than the regular build of mame.

Just extract the hiscoredat.zip into the folder that your mame.exe is in.

NOTE :- you need a mame build that supports the hiscore.dat, you can now download
such a file from the website downloads page, see below.

NOTE :-
as of mame 0.133u1 almost 1000 mame clone sets were renamed,if you are planning to use a later 
mame than mame 0.133u1 and upwards then use the hiscore.dat file,  
If however you use an older
version of mame than 0.133u1 then 
use the file hiscore(pre_mame0133u1).dat (you must rename it to hiscore.dat)

Also - as of mame 0.133u1 a lot of the names of clone mame roms were renamed, 
this also means that
all the relevent .hi (.cfg  & .nvram) files also need renaming.


Enjoy,
Leezer.

leezer@leezer.karoo.co.uk

unofficial hiscore.dat website :- www.mameworld.info/highscore (also hosts a build of mame
that supports the hiscore.dat)


(mame32fx also still supports the hiscore.dat as far as i know)
http://mame32fx.altervista.org/home.htm
